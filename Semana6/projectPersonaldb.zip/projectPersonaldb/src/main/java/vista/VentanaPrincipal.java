package vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import controlador.controller;

public class VentanaPrincipal extends JFrame implements ActionListener {

	private controller controlador; // objeto miCoordinador que permite la relacion entre esta clase y la clase
									// coordinador
	private JTextArea areaIntroduccion;
	private JLabel labelTitulo;
	private JButton botonAceptar;

	/**
	 * Establece la informacion que se presentara como introduccion del sistema
	 */
	public String textoIntroduccion = "";

	/**
	 * constructor de la clase donde se inicializan todos los componentes de la
	 * ventana principal
	 */
	public VentanaPrincipal() {
		// Instancia del controlador utilizado
		controlador = new controller();

		// Configuración de la Interfaz Gráfica GUI

		// Configuración de la ventana (JFrame)
		setSize(480, 350);
		setTitle("Mision TIC 2022");
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// Label de titulo
		labelTitulo = new JLabel("PATRON MODELO VISTA CONTROLADOR");
		labelTitulo.setBounds(60, 40, 380, 30);
		labelTitulo.setFont(new java.awt.Font("Verdana", 1, 15));
		add(labelTitulo);

		// Texte Area Informativo
		textoIntroduccion = "Aplicación MVC- Misión TIC 2022 ";
		areaIntroduccion = new JTextArea();
		areaIntroduccion.setBounds(50, 90, 380, 140);
		areaIntroduccion.setEditable(false);
		areaIntroduccion.setFont(new java.awt.Font("Verdana", 0, 14));
		areaIntroduccion.setLineWrap(true);
		areaIntroduccion.setText(textoIntroduccion);
		areaIntroduccion.setWrapStyleWord(true);
		add(areaIntroduccion);

		// Boton Acpetar
		botonAceptar = new JButton("Aceptar");
		botonAceptar.setBounds(170, 280, 120, 25);
		add(botonAceptar);
		botonAceptar.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == botonAceptar) {
			controlador.mostrarVentanaCRUD();

		}

	}
}
