package vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.vo.PersonaVo;
import controlador.controller;

public class VentanaCRUD extends JFrame implements ActionListener {

	private JLabel labelTitulo;
	private JTextField textCod, textNombre, textEdad, textTelefono, textProfesion;
	private JLabel cod, nombre, edad, telefono, profesion;
	private JButton botonInsertar, botonGuardar, botonCancelar, botonBuscar, botonModificar, botonEliminar,
			botonLimpiar;
	private controller control;

	/**
	 * constructor de la clase donde se inicializan todos los componentes de la
	 * ventana de busqueda
	 */

	public VentanaCRUD() {

		// Instancia del controlador utilizado
		control = new controller();

		// Configuración de la Interfaz Gráfica GUI

		// Configuración de la ventana (JFrame)
		setSize(480, 320);
		setTitle("Mision TIC 2022");
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);

		// Label de titulo
		labelTitulo = new JLabel("ADMINISTRAR PERSONAS");
		labelTitulo.setBounds(120, 20, 380, 30);
		labelTitulo.setFont(new java.awt.Font("Verdana", 1, 18));
		add(labelTitulo);

		// Label, campo Botón Buscar por ID
		cod = new JLabel("Codigo");
		cod.setBounds(20, 80, 80, 25);
		add(cod);
		textCod = new JTextField();
		textCod.setBounds(80, 80, 80, 25);
		add(textCod);
		botonBuscar = new JButton("Buscar");
		botonBuscar.setBounds(170, 80, 100, 25);
		add(botonBuscar);
		botonBuscar.addActionListener(this);

		// Campos de datos de Persona
		nombre = new JLabel("Nombre");
		nombre.setBounds(20, 120, 80, 25);
		add(nombre);
		textNombre = new JTextField();
		textNombre.setBounds(80, 120, 190, 25);
		add(textNombre);

		telefono = new JLabel("Telefono");
		telefono.setBounds(290, 160, 80, 25);
		add(telefono);
		textTelefono = new JTextField();
		textTelefono.setBounds(340, 160, 80, 25);
		add(textTelefono);

		profesion = new JLabel("Profesion");
		profesion.setBounds(20, 160, 80, 25);
		add(profesion);
		textProfesion = new JTextField();
		textProfesion.setBounds(80, 160, 190, 25);
		add(textProfesion);

		edad = new JLabel("Edad");
		edad.setBounds(290, 120, 80, 25);
		add(edad);
		textEdad = new JTextField();
		textEdad.setBounds(340, 120, 80, 25);
		add(textEdad);

		// Botones CRUD Primera Hilera

		botonInsertar = new JButton("Insertar");
		botonInsertar.setBounds(50, 220, 120, 25);
		add(botonInsertar);
		botonInsertar.addActionListener(this);

		botonModificar = new JButton("Modificar");
		botonModificar.setBounds(190, 220, 120, 25);
		add(botonModificar);
		botonModificar.addActionListener(this);

		botonEliminar = new JButton("Eliminar");
		botonEliminar.setBounds(330, 220, 120, 25);
		add(botonEliminar);
		botonEliminar.addActionListener(this);

		// Botones CRUD Segunda Hilera
		botonGuardar = new JButton("Guardar");
		botonGuardar.setBounds(50, 250, 120, 25);
		add(botonGuardar);
		botonGuardar.addActionListener(this);

		botonCancelar = new JButton("Cancelar");
		botonCancelar.setBounds(190, 250, 120, 25);
		add(botonCancelar);
		botonCancelar.addActionListener(this);

		botonLimpiar = new JButton("Limpiar");
		botonLimpiar.setBounds(330, 250, 120, 25);
		add(botonLimpiar);
		botonLimpiar.addActionListener(this);

		// Llamado al método para limpiar campos y Habilitarlos en la GUI
		limpiar();
		habilitar(true, false, false, false, false, true, false, true, true);

	}

	public void limpiar() {
		textCod.setText("");
		textNombre.setText("");
		textEdad.setText("");
		textTelefono.setText("");
		textProfesion.setText("");
	}

	public void habilitar(boolean codigo, boolean nombre, boolean edad, boolean tel, boolean profesion, boolean bBuscar,
			boolean bGuardar, boolean bModificar, boolean bEliminar) {
		// Habilitar - Deshabilitar campos de texto
		textCod.setEditable(codigo);
		textNombre.setEditable(nombre);
		textEdad.setEditable(edad);
		textProfesion.setEditable(profesion);
		textTelefono.setEditable(tel);

		// Habilitar - Deshabilitar Botones
		botonBuscar.setEnabled(bBuscar);
		botonGuardar.setEnabled(bGuardar);
		botonModificar.setEnabled(bModificar);
		botonEliminar.setEnabled(bEliminar);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == botonBuscar) {
			try {

				PersonaVo miPersona = control.consultarPersonas(Integer.parseInt(textCod.getText()));
				if (miPersona != null) {
					textNombre.setText(miPersona.getNombrePersona());
					textEdad.setText(miPersona.getEdadPersona() + "");
					textTelefono.setText(miPersona.getTelefonoPersona() + "");
					textProfesion.setText(miPersona.getProfesionPersona());
				} else {
					JOptionPane.showMessageDialog(null, "La persona no Existe", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			} catch (Exception e3) {
				JOptionPane.showMessageDialog(null, "Error al consultar", "Error", JOptionPane.ERROR_MESSAGE);
			}

		}

		if (e.getSource() == botonLimpiar) {
			limpiar();
		}

		if (e.getSource() == botonCancelar) {
			this.dispose();
		}

	}

}
