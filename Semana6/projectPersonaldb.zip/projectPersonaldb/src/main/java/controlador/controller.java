package controlador;

import java.sql.SQLException;
import modelo.dao.*;
import modelo.vo.*;
import vista.*;

public class controller {
    private PersonaDao personadao;

    public controller() {
        this.personadao = new PersonaDao();
    }

    public PersonaVo consultarPersonas(int codigo) throws SQLException {
        return this.personadao.consultarPersona(codigo);
    }

    public void mostrarVentanaCRUD() {
        VentanaCRUD vBuscar = new VentanaCRUD();
        vBuscar.setVisible(true);
    }

    public void mostrarVentanaPrincipal() {
        VentanaPrincipal vPrincipal = new VentanaPrincipal();
        vPrincipal.setVisible(true);
    }

}
