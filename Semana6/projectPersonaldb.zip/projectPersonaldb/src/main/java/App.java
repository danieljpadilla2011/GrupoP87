 import controlador.controller;

public class App {
    public static void main(String[] args) {
        controller control = new controller();
        control.mostrarVentanaPrincipal();

    }

}
