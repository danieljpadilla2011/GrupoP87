import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        FormularioCB formulario = new FormularioCB();
        formulario.setBounds(0, 0, 200, 200);
        // formulario.setResizable(false);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
