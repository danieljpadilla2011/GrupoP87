import javax.swing.*;

public class App {
    public static void main(String[] args) throws Exception {
        JFrame f = new JFrame();
        f.setBounds(10, 10, 300, 200);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
