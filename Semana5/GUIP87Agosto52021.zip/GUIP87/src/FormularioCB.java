import javax.swing.*;
import java.awt.event.*;

public class FormularioCB extends JFrame implements ItemListener {
    private JComboBox<String> cmbColores;

    public FormularioCB() {
        setLayout(null);
        cmbColores = new JComboBox<String>();
        cmbColores.setBounds(10, 10, 80, 20);
        add(cmbColores);
        cmbColores.addItem("rojo");
        cmbColores.addItem("verde");
        cmbColores.addItem("amarillo");
        cmbColores.addItem("azul");
        cmbColores.addItem("negro");
        cmbColores.addItemListener(this);
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == cmbColores) {
            String cad = cmbColores.getSelectedItem().toString();
            JOptionPane.showMessageDialog(null, cad, "Color Seleccionado", JOptionPane.INFORMATION_MESSAGE);

        }

    }

}
