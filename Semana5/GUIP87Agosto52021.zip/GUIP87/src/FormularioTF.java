import javax.swing.*;
import java.awt.event.*;

public class FormularioTF extends JFrame implements ActionListener {
    private JLabel lblUsuario;
    private JTextField cmpUsuario;
    private JButton btnAceptar;

    public FormularioTF() {
        setLayout(null);
        lblUsuario = new JLabel("Usuario");
        lblUsuario.setBounds(10, 10, 100, 30);
        add(lblUsuario);
        cmpUsuario = new JTextField();
        cmpUsuario.setBounds(120, 10, 150, 30);
        add(cmpUsuario);
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(10, 60, 100, 30);
        add(btnAceptar);
        btnAceptar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAceptar) {
            String cad = cmpUsuario.getText();
            JOptionPane.showMessageDialog(this, cad, "Usuario Digitado", JOptionPane.INFORMATION_MESSAGE);
            cmpUsuario.setText("Valor Asignado");
        }

    }

}
