import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FormularioTA extends JFrame {
    private JTextField cmpNombre;
    private JTextArea txaInfo;
    private JScrollPane scrPanel;

    public FormularioTA() {
        setLayout(null);
        cmpNombre = new JTextField();
        cmpNombre.setBounds(10, 10, 200, 30);
        add(cmpNombre);
        txaInfo = new JTextArea();
        // txaInfo.setBounds(10, 50, 400, 300);
        // add(txaInfo);
        scrPanel = new JScrollPane(txaInfo);
        scrPanel.setBounds(10, 50, 400, 300);
        add(scrPanel);
    }
}
