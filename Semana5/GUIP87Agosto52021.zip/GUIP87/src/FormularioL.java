import javax.swing.*;

public class FormularioL extends JFrame {
    private JLabel label1, label2;

    public FormularioL() {
        setLayout(null);
        label1 = new JLabel("Mision TIC 2022");
        label1.setBounds(10, 20, 200, 20);
        add(label1);
        label2 = new JLabel("programación");
        label2.setBounds(10, 60, 100, 20);
        add(label2);
    }

}
