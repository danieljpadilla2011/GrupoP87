import javax.swing.*;
import java.awt.event.*;

public class FormularioB extends JFrame implements ActionListener {
    private JButton btnAceptar;

    public FormularioB() {
        setLayout(null);
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(300, 200, 100, 30);
        add(btnAceptar);
        btnAceptar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAceptar) {
            JOptionPane.showMessageDialog(this, "Se ha presionado el boton Aceptar", "Info",
                    JOptionPane.WARNING_MESSAGE);
        }

    }

}
