import javax.swing.*;

public class Formulario extends JFrame {

    public Formulario() {

    }

}
