import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        // Lectura de Archivos

        try {
            File f = new File("nombres.txt");
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                System.out.println(linea);
            }

        } catch (Exception e) {
            System.out.println("Falla en lectura de archivo: " + e.getMessage());
            e.getStackTrace();
        }

        // Escritura de Archivos
        String datos[] = { "ManzanasN", "PerasN" };
        FileWriter archivo2 = new FileWriter("frutas.txt");
        for (String i : datos) {
            archivo2.write(i + "\n");
        }
        archivo2.close();

        // Añadir al archivo

        String datos2[] = { "Limon", "Lulo" };
        FileWriter archivo3 = new FileWriter("frutas.txt", true);
        for (String i : datos2) {
            archivo3.write(i + "\n");
        }
        archivo3.close();

    }
}
