package modelo.vo;

public class Requerimiento_1Vo {
    // Su código
}
