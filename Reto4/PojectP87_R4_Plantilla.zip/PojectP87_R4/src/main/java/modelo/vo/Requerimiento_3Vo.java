package modelo.vo;

public class Requerimiento_3Vo {
    // Su código
}
