
import vista.VistaRequerimientos;

/**
 * Esta clase solo se debe usar para hacer pruebas locales, no se debe subir en
 * iMaster
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Requerimiento 1");
        VistaRequerimientos.requerimiento1();       

    }
}
